function GetConfig() as Object
    return {
        "dropbox": {
            "appKey": "	mx94hkkbegt4kd9"
        },
        "google": {
            "clientId": "928309960356-0pii0of1vn0hggc3oei277gh280c9ki4.apps.googleusercontent.com",
            "clientSecret": "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"
        },
        "slideshow": {
            "interval": 30,
            "folderName": "/RokuPhotos" ' Dropbox paths start with /
        }
    }
end function